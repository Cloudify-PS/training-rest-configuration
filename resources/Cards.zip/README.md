# cloudify_assignment
Cloudify Assignment for Developer - Cards API
